import allure
from playwright.sync_api import Page, expect
import time
from datetime import datetime

class TestDemoQAForm:
    def test_fill_registration_form(self, page: Page):
        with allure.step("Открываем страницу DemoQA"):
            page.goto("https://demoqa.com/webtables")

        with allure.step("Кликаем кнопку 'Add' через CSS-селектор"):
            page.locator("button:has-text('Add')").click()

        with allure.step("Ждём, что модальное окно с формой открылось"):
            # Модальное окно регистрации
            registration_form = page.locator("#registration-form-modal")
            registration_form.wait_for(state="visible")
            assert registration_form.is_visible(), "Модальное окно регистрации не открылось"

        with allure.step("Проверяем заголовок модального окна"):
            expect(registration_form).to_contain_text("Registration Form")

        with allure.step("Заполняем First Name через placeholder"):
            first_name_input = page.locator("input[placeholder='First Name']")
            first_name_input.fill("Иван")

        with allure.step("Заполняем остальные поля"):

            page.locator("input[placeholder='Last Name']").fill("Иванов")

            page.locator("input[placeholder='name@example.com']").fill("ivan@mail.ru")

            page.locator("input[placeholder='Age']").fill("23")

            page.locator("input[placeholder='Salary']").fill("250000")

            page.locator("input[placeholder='Department']").fill("QA")

        with allure.step("Нажимаем Submit"):
            submit_button = page.locator("button:has-text('Submit')")
            submit_button.click()
        time.sleep(10)

    def test_automation_practice_form(self, page: Page):
        with allure.step("Открываеем страницу DemoQA"):
            page.goto("https://demoqa.com/automation-practice-form")

        with allure.step("Заполняем поля:"):
            first_name = page.locator("#firstName")
            first_name.fill("Иван")
            assert first_name.input_value() == "Иван"

        with allure.step("Заполняем Last Name через type()"):
            last_name = page.locator("#lastName")
            last_name.type("Иванов", delay=100)
            assert last_name.input_value() == "Иванов"

        with allure.step("Заполняем Email через type()"):
            email = page.locator("#userEmail")
            email.type("ivan@mail.ru", delay=50)
            assert email.input_value() == "ivan@mail.ru"

        with allure.step("Выбираем Gender = Male (радиобатон)"):
            page.get_by_label("Male", exact=True).check()
            assert page.locator("#gender-radio-1").is_checked()

        with allure.step("Заполняем Mobile через type()"):
            mobile = page.locator("#userNumber")
            mobile.fill("8999999999")
            assert mobile.input_value() == "8999999999"

        with allure.step("Выбираем Subjects через автокомплит"):
            subjects = page.locator("#subjectsInput")
            subjects.fill("Math")
            page.locator(".subjects-auto-complete__option").first.click()

        with allure.step("Выбираем hobbies через чекбоксы"):
            page.get_by_label("Sports").check()
            page.get_by_label("Reading").check()
            assert page.locator("#hobbies-checkbox-1").is_checked()
            assert page.locator("#hobbies-checkbox-2").is_checked()
            assert not page.locator("#hobbies-checkbox-3").is_checked()

        with allure.step("Загружаем файл (Upload Picture)"):
            page.locator("#uploadPicture").set_input_files({
                "name": "test.txt",
                "mimeType": "text/plain",
                "buffer": b"hello world",
            })

        with allure.step("Заполняем Current Address"):
            page.locator("#currentAddress").fill("г. Москва, ул. Пушкина, д. 1")

        with allure.step("Выбираем State (выпадающий список)"):
            page.locator("#state").click()
            page.locator("#react-select-3-option-0").click()

        with allure.step("Выбираем City"):
            page.locator("#city").click()
            page.locator("#react-select-4-option-0").click()

        with allure.step("Проверяем, что Date of Birth по умолчанию == сегодня"):
            date_input = page.locator("#dateOfBirthInput")
            actual_value = date_input.get_attribute("value")
            expected_value = datetime.now().strftime("%d %b %Y")
            assert actual_value == expected_value, (
                f"Значение Date of Birth: ожидали '{expected_value}' (сегодня), "
                f"получили '{actual_value}'"
            )

        with allure.step("Нажимаем Submit"):
            page.locator("#submit").click()

        with allure.step("Проверяем, что модалка с результатом открылась"):
            result_modal = page.locator(".modal-content")
            expect(result_modal).to_be_visible()

        with allure.step("Проверяем, что в результате есть наши данные"):
            expect(result_modal).to_contain_text("Иван")
            expect(result_modal).to_contain_text("Иванов")
            expect(result_modal).to_contain_text("ivan@mail.ru")
        time.sleep(10)


