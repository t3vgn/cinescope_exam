from pages.base_page import BasePage

class CinescopeMoviePage(BasePage):
    def __init__(self, page):
        super().__init__(page)
        self.url = f"{self.home_url}movies"

        self.review_input = '[data-qa-id="movie_review_input"]'
        self.submit_review_button = '[data-qa-id="movie_review_submit_button"]'
        # Селектор для триггера рейтинга
        self.rating_combobox = '[data-qa-id="movie_rating_select"]'

    def open_movie(self, movie_id: int):
        self.open_url(f"{self.url}/{movie_id}")

    def select_rating(self, rating: str):
        """Выбирает оценку в кастомном выпадающем списке."""
        # Шаг 1: Кликаем по триггеру, чтобы открыть список
        # Используем force=True, так как Radix-компоненты иногда блокируют обычный клик
        self.page.locator(self.rating_combobox).click(force=True)

        # Шаг 2: Кликаем по опции с нужным текстом (например, "5")
        self.page.get_by_role("option", name=rating).click()

    def leave_review(self, text: str, rating: str = "5"):
        """Оставить отзыв с оценкой."""
        self.enter_text(self.review_input, text)
        self.select_rating(rating)   # Выбираем оценку перед отправкой
        self.click(self.submit_review_button)