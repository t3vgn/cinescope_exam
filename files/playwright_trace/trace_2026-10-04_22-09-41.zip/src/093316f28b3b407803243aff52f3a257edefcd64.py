import allure
import pytest
from playwright.sync_api import Page, expect
import time

class TestDemoQAForm:
    def test_fill_registration_form(self, page: Page):
        with allure.step("Открываеем страницу DemoQA"):
            page.goto("https://demoqa.com/webtables")

        with allure.step("Кликаем кнопку 'Add' через CSS-селектор"):
            page.locator("button:has-text('Add')").click()

        with allure.step("Ждём, что модальное окно с формой открылось"):
            # Модальное окно регистрации
            registration_form = page.locator("#registration-form-modal")
            registration_form.wait_for(state="visible")
            assert registration_form.is_visible(), "Модальное окно регистрации не открылось"

        with allure.step("Проверяем заголовок модального окна"):
            modal_title = registration_form.locator("h5")
            expect(modal_title).to_have_text("Registration Form")

        with allure.step("Заполняем First Name через placeholder"):
            first_name_input = page.locator("input[placeholder='First Name']")
            first_name_input.fill("Иван")
        time.sleep(10)