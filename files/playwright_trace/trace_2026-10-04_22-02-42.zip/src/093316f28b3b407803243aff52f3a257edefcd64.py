import allure
import pytest
from playwright.sync_api import Page, expect

class TestDemoQAForm:
    def test_fill_registration_form(self, page: Page):
        with allure.step("Открываеем страницу DemoQA"):
            page.goto("https://demoqa.com/webtables")

        with allure.step("Кликаем кнопку 'Add' через CSS-селектор"):
            page.locator("button:has-text('Add')").click()

        with allure.step("Ждём, что модальное окно с формой открылось"):
            # Модальное окно регистрации
            registration_form = page.locator("#registration-form-modal")