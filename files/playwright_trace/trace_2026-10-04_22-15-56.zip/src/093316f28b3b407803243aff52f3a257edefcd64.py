import allure
import pytest
from playwright.sync_api import Page, expect
import time

class TestDemoQAForm:
    def test_fill_registration_form(self, page: Page):
        with allure.step("Открываеем страницу DemoQA"):
            page.goto("https://demoqa.com/webtables")

        with allure.step("Кликаем кнопку 'Add' через CSS-селектор"):
            page.locator("button:has-text('Add')").click()

        with allure.step("Ждём, что модальное окно с формой открылось"):
            # Модальное окно регистрации
            registration_form = page.locator("#registration-form-modal")
            registration_form.wait_for(state="visible")
            assert registration_form.is_visible(), "Модальное окно регистрации не открылось"

        with allure.step("Проверяем заголовок модального окна"):
            expect(registration_form).to_contain_text("Registration Form")

        with allure.step("Заполняем First Name через placeholder"):
            first_name_input = page.locator("input[placeholder='First Name']")
            first_name_input.fill("Иван")

        with allure.step("Заполняем остальные поля"):

            page.locator("input[placeholder='Last Name']").fill("Иванов")

            page.locator("input[placeholder='name@example.com']").fill("ivan@mail.ru")

            page.locator("input[placeholder='Age']").fill("23")

            page.locator("input[placeholder='Salary']").fill("250 000 руб.")

            page.locator("input[placeholder='Department']").fill("QA")

        with allure.step("Нажимаем Submit"):
            submit_button = page.locator("button:has-text('Submit')")
            submit_button.click()
        time.sleep(10)